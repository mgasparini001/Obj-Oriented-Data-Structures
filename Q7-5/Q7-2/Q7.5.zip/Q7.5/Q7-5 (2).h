#pragma once
#include <string>
#include <iostream>
using namespace std;

class SongNode {
private:
	string songName;
	string artistName;
	SongNode* prevSong;
	SongNode* nextSong;

public: 
	SongNode(string s, string a); //prototype for contructor
	string getSong(); //getSong function fetches the satellite data for this node
	
	string getArtist();
	void setNext(SongNode* nxt);
		 //setNext sets the next element in list to whatever the  

	SongNode* getNext(); //returns address of next node

	void setPrev(SongNode* prev);

	SongNode* getPrev();

	

};
