#include <iostream>
#include "DLPlaylist.h"
#include "SongNode.h"

using namespace std;
SongNode* DLPlaylist::getCurrent() { 
	return Index; //dereferences (getting the value being referred to)
	//the current loaction, returning the node at that address
} 

void DLPlaylist::setCurrent(SongNode* newPos)
{
	Index = newPos; 
}

void DLPlaylist::goToNext() { 
	Index = (*Index).getNext(); 
} 

void DLPlaylist::goToPrev() {
	Index = (*Index).getPrev(); 
}

void DLPlaylist::goToStart() {
	Index = startOfList; 
}

void DLPlaylist::goToTail() {
	Index = tailOfList;
}


	DLPlaylist::DLPlaylist(SongNode* start, SongNode* tail) {
		Index = start; //constructor. need a node created first before creating a list
		startOfList = start; 
		tailOfList = tail;
	} 
	

	string DLPlaylist::toString() {
		int i = 1;
		string playlist;
		Index = startOfList;
		while (Index != nullptr) {
			playlist = playlist + to_string(i) + ". \"" + Index->getSong() + "\" by " + Index->getArtist() + "\n";
			Index = Index->getNext();
			i++;
		}
		Index = startOfList;
		return playlist;
	}
	void DLPlaylist::insertAtBeginning(SongNode* newNode) {

		newNode->setNext(startOfList);
		if (startOfList != nullptr) {
			
			startOfList->setPrev(newNode);
		}
		startOfList = newNode;

	}

	void DLPlaylist::insertAtEnd(SongNode* newNode) {
		if (tailOfList != nullptr) {

				newNode->setPrev(tailOfList);
				tailOfList->setNext(newNode);
				tailOfList = newNode;
		}
		else {
			startOfList = newNode;
		}
	}

	void DLPlaylist::insertBeforeCurrentLocation(int& pos, SongNode* newNode) {
		int i = 1;
		SongNode* tempIndex = startOfList;
		if (tempIndex != nullptr) {
			while (i < pos) {//i = 1  index = 1, i=2  index = 2, i = 3 index = 3, insert new before 3 and after 2, making it 3
				tempIndex = tempIndex->getNext();
				i++;
			}
			newNode->setNext(tempIndex);
			newNode->setPrev(tempIndex->getPrev());
			(tempIndex->getPrev())->setNext(newNode);
			tempIndex->setPrev(newNode);
			
		}
		else {
			insertAtBeginning(newNode);
		}
	}

	void DLPlaylist::deleteNode(SongNode* node) {
		if (node->getPrev() != nullptr) {
			(node->getPrev())->setNext(node->getNext());

		}
		else {
			
			startOfList = node->getNext();
		}
		if (node->getNext() != nullptr) {
			(node->getNext())->setPrev(node->getPrev());
		}
		else {
			
			tailOfList = node->getPrev();
		}
		node->setNext(nullptr);
		node->setPrev(nullptr);
		delete node;
	}
	
