#include <iostream>
#include "SongNode.h"
using namespace std;



	SongNode::SongNode(string s, string a) {
		songName = s;
		artistName = a;
		prevSong = NULL;
		nextSong = NULL;
	} //prototype for contructor
	string SongNode::getSong() { 
		return songName;
	} //getSong function fetches the satellite data for this node

	string SongNode::getArtist() {
		return artistName;
	}
	void SongNode::setNext(SongNode* nxt)
	{
		nextSong = nxt; //setNext sets the next element in list to whatever the arg is.
	}

	SongNode* SongNode::getNext() { 
		return nextSong;
	} //returns address of next node

	void SongNode::setPrev(SongNode* prev)
	{
		prevSong = prev;
	}

	SongNode* SongNode::getPrev() {
		return prevSong;
	}






