#pragma once
#include <iostream>
#include "SongNode.h"
class DLPlaylist {
private:
	SongNode* Index; //keeps track of where we are in list
	SongNode* startOfList; //returns to start of list 
	SongNode* tailOfList;

public: 
	SongNode* getCurrent(); //dereferences (getting the value being referred to)
	//the current loaction, returning the node at that address

	void setCurrent(SongNode* newPos);
	

	void goToNext(); //moves index of list to next location

	void goToPrev();

	void goToTail();

	void goToStart();

	//make the end of list move next once after inserting if Index = size
	//make beginning move next once after insert if Index = 1
	void insertAtBeginning(SongNode* newNode);

	void insertAtEnd(SongNode* newNode); //inserts passed node
	
	void insertBeforeCurrentLocation(int& pos, SongNode* newNode);

	string toString();

	void deleteNode(SongNode* node); 
	//int getPlaylistLength();
	

	DLPlaylist(SongNode* start, SongNode* tail);

};